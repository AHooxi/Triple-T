from machine import Pin
import time
import random



#THE BOARD:
#1     2     3
#4     5     6
#7     8     9

# --- SENSORS ---
SS1= Pin(16, Pin.IN, Pin.PULL_DOWN)
SS2= Pin(17, Pin.IN, Pin.PULL_DOWN)
SS3= Pin(18, Pin.IN, Pin.PULL_DOWN)
SS4= Pin(19, Pin.IN, Pin.PULL_DOWN)
SS5= Pin(20, Pin.IN, Pin.PULL_DOWN)
SS6= Pin(21, Pin.IN, Pin.PULL_DOWN)
SS7= Pin(26, Pin.IN, Pin.PULL_DOWN)
SS8= Pin(27, Pin.IN, Pin.PULL_DOWN)
SS9= Pin(28, Pin.IN, Pin.PULL_DOWN)
current_square=None



win=[
    [1,2,3],
    [4,5,6],
    [7,8,9],
    [1,4,7],
    [2,5,8],
    [3,6,9],
    [1,5,9],
    [3,5,7],
    ]

# A B C D on driver
Ax = Pin(0, Pin.OUT)
Bx = Pin(1, Pin.OUT)
Cx = Pin(2, Pin.OUT)
Dx = Pin(3, Pin.OUT)

Ay = Pin(8, Pin.OUT)
By = Pin(9, Pin.OUT)
Cy = Pin(10, Pin.OUT)
Dy = Pin(11, Pin.OUT)

# Half-step sequence
step_sequence = [
    [1,0,0,0],
    [1,1,0,0],
    [0,1,0,0],
    [0,1,1,0],
    [0,0,1,0],
    [0,0,1,1],
    [0,0,0,1],
    [1,0,0,1]
]

SQR_x=0
SQR_y=0
initial=0
def MATRIX_SYSTEM(current_sqr, new_sqr):
    conversion= 1028/20.4 #1028 is one revolution, 20.4 is the distance in cm/revolution
    distance=5.5 #distance between squares (cm)
    if current_sqr==1: #change to current square
        if new_sqr==initial:
            SRQ_x=distance*conversion
            SRQ_y=-distance*conversion*2.5
 

    if current_sqr==2: #change to current square
        if new_sqr==initial:
            SRQ_x=0
            SRQ_y=-distance*conversion*2.5
 

    if current_sqr==3: #change to current square
        if new_sqr==initial:
            SRQ_x=-distance*conversion
            SRQ_y=-distance*conversion*2.5

    if current_sqr==4: #change to current square
        if new_sqr==initial:
            SRQ_x=distance*conversion
            SRQ_y=-distance*conversion*1.5

    if current_sqr==5: #change to current square
        if new_sqr==initial:
            SRQ_x=0
            SRQ_y=-distance*conversion*1.5
        
    if current_sqr==6: #change to current square
        if new_sqr==initial:
            SRQ_x=-distance*conversion
            SRQ_y=-distance*conversion*1.5
            
    if current_sqr==7: #change to current square
        if new_sqr==initial:
            SRQ_x=distance*conversion
            SRQ_y=-distance*conversion*0.5
    
    if current_sqr==8: #change to current square
        if new_sqr==initial:
            SRQ_x=0
            SRQ_y=-distance*conversion*0.5
    if current_sqr==9: #change to current square
        if new_sqr==initial:
            SRQ_x=-distance*conversion
            SRQ_y=-distance*conversion*0.5
    if new_sqr==initial:
        if current_sqr==1:
            SRQ_x=-distance*conversion
            SRQ_y=distance*conversion*2.5
        if current_sqr==2:
            SRQ_x=0
            SRQ_y=distance*conversion*2.5
        if current_sqr==3:
            SRQ_x=distance*conversion
            SRQ_y=distance*conversion*2.5
        if current_sqr==4:
            SRQ_x=-distance*conversion
            SRQ_y=distance*conversion*1.5
        if current_sqr==5:
            SRQ_x=0
            SRQ_y=distance*conversion*1.5
        if current_sqr==6:
            SRQ_x=distance*conversion
            SRQ_y=distance*conversion*1.5
        if current_sqr==7:
            SRQ_x=-distance*conversion
            SRQ_y=distance*conversion*0.5
        if current_sqr==8:
            SRQ_x=0
            SRQ_y=distance*conversion*0.5
        if current_sqr==9:
            SRQ_x=distance*conversion
            SRQ_y=distance*conversion*0.5
        if new_sqr==0:
            SRQ_x=0
            SRQ_y=0
    return SRQ_x, SRQ_y


def step_motor_x(steps, delay=0.001):
    for _ in range(int(steps)):
        for step in step_sequence:
            Ax.value(step[0])
            Bx.value(step[1])
            Cx.value(step[2])
            Dx.value(step[3])
            time.sleep(delay)

def step_motor_reverse_x(steps, delay=0.001):
    for _ in range(int(steps)):
        for step in reversed(step_sequence):
            Ax.value(step[0])
            Bx.value(step[1])
            Cx.value(step[2])
            Dx.value(step[3])
            time.sleep(delay)


def step_motor_y(steps, delay=0.001):
    for _ in range(int(steps)):
        for step in step_sequence:
            Ay.value(step[0])
            By.value(step[1])
            Cy.value(step[2])
            Dy.value(step[3])
            time.sleep(delay)

def step_motor_reverse_y(steps, delay=0.001):
    for _ in range(int(steps)):
        for step in reversed(step_sequence):
            Ay.value(step[0])
            By.value(step[1])
            Cy.value(step[2])
            Dy.value(step[3])
            time.sleep(delay)


SOL=Pin(12, Pin.OUT)
A = Pin(4, Pin.OUT)
B = Pin(5, Pin.OUT)
C = Pin(6, Pin.OUT)
D = Pin(7, Pin.OUT)

step_sequence = [
    [1,0,0,0],
    [1,1,0,0],
    [0,1,0,0],
    [0,1,1,0],
    [0,0,1,0],
    [0,0,1,1],
    [0,0,0,1],
    [1,0,0,1]
]

def height():
    conversion= 1028/20.4
    height= conversion * 10
    return int(height)

def solenoid_on():
    SOL.value(1)

def solenoid_off():
    SOL.value(0)

def Reels_down(steps, delay=0.02):
    for _ in range(int(steps)):
        for step in step_sequence:
            A.value(step[0])
            B.value(step[1])
            C.value(step[2])
            D.value(step[3])
            time.sleep(delay)
    return

def Reels_up(steps, delay=0.02):
    for _ in range(int(steps)):
        for seq in reversed(step_sequence):
            A.value(seq[0])
            B.value(seq[1])
            C.value(seq[2])
            D.value(seq[3])
            time.sleep(delay)


solenoid_off()


def check_win(moves): #GOT FROM AI
    moves = set(moves)
    for combo in win:
        if set(combo).issubset(moves):
            return True
    return False

def moving_claw_human(new_sqr, current_sqr): #Just in case what to expand to human vs human with only one claw (no placing the pieces)
    SRQ_x, SRQ_y = MATRIX_SYSTEM(current_sqr, new_sqr)
    time.sleep(2)
    if SRQ_x >= 0:
        step_motor_x(SRQ_x)
    elif SRQ_x < 0:
        SRQ_x=-SRQ_x
        step_motor_reverse_x(SRQ_x)
    if SRQ_y >= 0:
        step_motor_y(SRQ_y)
    elif SRQ_y < 0:
        SRQ_y=-SRQ_y
        step_motor_reverse_y(SRQ_y)
    time.sleep(2)
    return 
def moving_claw_robot(new_sqr, current_sqr): #MOVING THE ROBOT
    SRQ_x, SRQ_y = MATRIX_SYSTEM(current_sqr, new_sqr)
    time.sleep(2)
    if SRQ_x >= 0:
        step_motor_x(SRQ_x)
    elif SRQ_x < 0:
        SRQ_x=-SRQ_x
        step_motor_reverse_x(SRQ_x)
    if SRQ_y >= 0:
        step_motor_y(SRQ_y)
    elif SRQ_y < 0:
        SRQ_y=-SRQ_y
        step_motor_reverse_y(SRQ_y)
    time.sleep(2)
    return

def read_sensors(available):
    if SS1.value()==1 and 1 in available:
        return 1
    elif SS2.value()==1 and 2 in available:
        return 2
    elif SS3.value()==1 and 3 in available:
        return 3
    elif SS4.value()==1 and 4 in available:
        return 4
    elif SS5.value()==1 and 5 in available:
        return 5
    elif SS6.value()==1 and 6 in available:
        return 6
    elif SS7.value()==1 and 7 in available:
        return 7
    elif SS8.value()==1 and 8 in available:
        return 8
    elif SS9.value()==1 and 9 in available:
        return 9

def robot(player1, CPU, game): #LOGIC OF ROBOT
    board = {"1","2","3","4","5","6","7","8","9"}
    available = list(board - set(game))
    winning_move=[move for move in available if check_win(CPU + [move])]# got from AI
    blocking_move=[move for move in available if check_win(player1 + [move])]#USE logic based off of AI
    if blocking_move and not winning_move:
        return blocking_move[random.randint(0, len(blocking_move)-1)]

    if winning_move:
        return winning_move[random.randint(0, len(winning_move)-1)]

    if 5 in available: #USE logic based off of AI
        return 5
    
    corners= [m for m in [1,3,7,9] if m in available]
    if corners: #USE logic based off of AI
        return corners[random.randint(0, len(corners)-1)]


    if not blocking_move or winning_move or corners or 5:
        return available[random.randint(0, len(available)-1)]


def main_board():
    board = [1,2,3,4,5,6,7,8,9]
    playable_move_1=True
    playable_move_2=True
    playable_move_3=True
    playable_move_4=True
    playable_move_5=True
    playable_move_6=True
    playable_move_7=True
    playable_move_8=True
    playable_move_9=True
 
    game=[]
    player1=[]
    CPU=[]
    print("You are first")
    time.sleep(3)
    for row in board:
        turn_player=False
        while turn_player==False:
            turn_player1 = None
            turn_player1=read_sensors(board)
 
            current_square= turn_player1   
            if turn_player1 is not None:
                    game.append(turn_player1)
                    player1.append(turn_player1)
                    turn_player = True

                    print(game)
            if check_win(player1):
                        print("PLAYER1 WINS!")
                        return
            if len(game) == 9:
                        print("Game over! It's a draw.")
                        return
            time.sleep(2)

        while turn_player==True:
                print(f"{game}")

                robot_move=robot(player1, CPU, game)
                if robot_move in game:
                    print("sorry you have to retry, this is what is current:"+ f"{game}")
                else:
                    if playable_move_1==True and robot_move == 1:
                            playable_move_1=False
                            while SS1.value():
                                pass
                    elif playable_move_2==True and robot_move == 2:
                            playable_move_2=False
                            while SS2.value():
                                pass
                    elif playable_move_3==True and robot_move == 3:
                            playable_move_3=False
                            while SS3.value():
                                pass
                    elif playable_move_4==True and robot_move == 4:
                            playable_move_4=False
                            while SS4.value():
                                pass
                    elif playable_move_5==True and robot_move == 5:
                            playable_move_5=False
                            while SS5.value():
                                pass
                    elif playable_move_6==True and robot_move == 6:
                            playable_move_6=False
                            while SS6.value():
                                pass
                    elif playable_move_7==True and robot_move == 7:
                            playable_move_7=False
                            while SS7.value():
                                pass
                    elif playable_move_8==True and robot_move == 8:
                            playable_move_8=False
                            while SS8.value():
                                pass
                    elif playable_move_9==True and robot_move == 9:
                            playable_move_9=False
                            while SS9.value():
                                pass
                        
                    moving_claw_robot(robot_move, 0) 
                    print(f"{moving_claw_robot(robot_move, 0)}")
                    time.sleep(2)
                    Reels_down(height(), delay=0.02)
                    time.sleep(2)
                    solenoid_off()
                    Reels_up(height(), delay=0.02)
                    if robot_move is not None:
                            game.append(robot_move)
                            CPU.append(robot_move)
                    print(game)
                    if check_win(CPU):
                            print("CPU WINS!")
                            return
                    if len(game) == 9:
                            print("Game over! It's a draw.")
                            return
                    turn_player=False

                    time.sleep(2)
                    moving_claw_robot(initial, robot_move)
                    time.sleep(2)
                    Reels_down(height(), delay=0.02)
                    solenoid_on()
                    time.sleep(2)
                    Reels_up(height(), delay=0.02)
                


main_board()