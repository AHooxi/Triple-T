from machine import Pin
import time
import random

# ========================
# --- CONFIG ---
# ========================

# Board layout
# 1  2  3
# 4  5  6
# 7  8  9

HOME = 0
DISTANCE = 6.5
CONVERSION = 1028 / 20.4
HEIGHT=8
HEIGHTRESET=5

# ========================
# --- SENSORS ---
# ========================

sensors = {
    1: Pin(16, Pin.IN, Pin.PULL_DOWN),
    2: Pin(17, Pin.IN, Pin.PULL_DOWN),
    3: Pin(18, Pin.IN, Pin.PULL_DOWN),
    4: Pin(19, Pin.IN, Pin.PULL_DOWN),
    5: Pin(20, Pin.IN, Pin.PULL_DOWN),
    6: Pin(21, Pin.IN, Pin.PULL_DOWN),
    7: Pin(22, Pin.IN, Pin.PULL_DOWN),
    8: Pin(26, Pin.IN, Pin.PULL_DOWN),
    9: Pin(28, Pin.IN, Pin.PULL_DOWN),
}

# ========================
# --- STEPPER PINS ---
# ========================

Ax = Pin(0, Pin.OUT)
Bx = Pin(1, Pin.OUT)
Cx = Pin(2, Pin.OUT)
Dx = Pin(3, Pin.OUT)

Ay = Pin(8, Pin.OUT)
By = Pin(9, Pin.OUT)
Cy = Pin(10, Pin.OUT)
Dy = Pin(11, Pin.OUT)

A = Pin(4, Pin.OUT)
B = Pin(5, Pin.OUT)
C = Pin(6, Pin.OUT)
D = Pin(7, Pin.OUT)

SOL = Pin(12, Pin.OUT)

# ========================
# --- STEP SEQUENCE ---
# ========================

STEP_SEQUENCE = [
    [1,0,0,0],
    [1,1,0,0],
    [0,1,0,0],
    [0,1,1,0],
    [0,0,1,0],
    [0,0,1,1],
    [0,0,0,1],
    [1,0,0,1]
]

# ========================
# --- COORDINATES ---
# ========================

coords = {
    1:(-1,3), 2:(0,3), 3:(1,3),
    4:(-1,2), 5:(0,2), 6:(1,2),
    7:(-1,1), 8:(0,1), 9:(1,1),
    HOME:(0,0)
}

# ========================
# --- MOVEMENT ---
# ========================

def move_to(current, target):
    cx, cy = coords[current]
    tx, ty = coords[target]

    dx = (tx - cx) * DISTANCE * CONVERSION
    dy = (ty - cy) * DISTANCE * CONVERSION

    move_x(dx)
    move_y(dy)

def move_x(steps):
    steps = int(abs(steps))
    seq = STEP_SEQUENCE if steps >= 0 else reversed(STEP_SEQUENCE)

    for _ in range(steps):
        for s in seq:
            Ax.value(s[0])
            Bx.value(s[1])
            Cx.value(s[2])
            Dx.value(s[3])
            time.sleep(0.001)

def move_y(steps):
    steps = int(abs(steps))
    seq = STEP_SEQUENCE if steps >= 0 else reversed(STEP_SEQUENCE)

    for _ in range(steps):
        for s in seq:
            Ay.value(s[0])
            By.value(s[1])
            Cy.value(s[2])
            Dy.value(s[3])
            time.sleep(0.001)

# ========================
# --- CLAW ---
# ========================

def height():
    return int(CONVERSION * HEIGHT)

def height_reset():
    return int(CONVERSION * HEIGHTRESET)

def reels_down():
    for _ in range(height()):
        for s in STEP_SEQUENCE:
            A.value(s[0])
            B.value(s[1])
            C.value(s[2])
            D.value(s[3])
            time.sleep(0.02)
def reels_down_reset():
    for _ in range(height_reset()):
        for s in STEP_SEQUENCE:
            A.value(s[0])
            B.value(s[1])
            C.value(s[2])
            D.value(s[3])
            time.sleep(0.02)
def reels_up():
    for _ in range(height()):
        for s in reversed(STEP_SEQUENCE):
            A.value(s[0])
            B.value(s[1])
            C.value(s[2])
            D.value(s[3])
            time.sleep(0.02)
def reels_up_reset():
    for _ in range(height_reset()):
        for s in reversed(STEP_SEQUENCE):
            A.value(s[0])
            B.value(s[1])
            C.value(s[2])
            D.value(s[3])
            time.sleep(0.02)
def grab():
    SOL.value(1)

def release():
    SOL.value(0)

# ========================
# --- SENSOR INPUT ---
# ========================

def read_sensors(available):
    for pos, sensor in sensors.items():
        if sensor.value() == 1 and pos in available:
            time.sleep(0.02)  # short debounce
            if sensor.value() == 1:  # still pressed
                return pos
    return None

# ========================
# --- GAME LOGIC ---
# ========================

win = [
    [1,2,3],[4,5,6],[7,8,9],
    [1,4,7],[2,5,8],[3,6,9],
    [1,5,9],[3,5,7]
]

def check_win(moves):
    moves = set(moves)
    return any(set(w).issubset(moves) for w in win)

def robot_move(player, cpu, game):
    available = [i for i in range(1,10) if i not in game]

    if not available:
        return None

    for m in available:
        if check_win(cpu + [m]):
            return m

    for m in available:
        if check_win(player + [m]):
            return m

    if 5 in available:
        return 5

    corners = [c for c in [1,3,7,9] if c in available]
    if corners:
        return corners[random.randint(0, len(corners) - 1)]

    return available[random.randint(0, len(available) - 1)]

# ========================
# --- MAIN LOOP ---
# ========================

def main():
    game = []
    player = []
    cpu = []
    release()
    current_pos = HOME
    reels_up()
    reels_down_reset()
    grab()
    reels_up_reset()
    print("You are first")
    time.sleep(2)

    while True:

        # PLAYER TURN
        move = None
        while move is None:
            move = read_sensors([i for i in range(1,10) if i not in game])

        print("Player:", move)
        game.append(move)
        player.append(move)

        if check_win(player):
            print("PLAYER WINS")
            return

        if len(game) == 9:
            print("DRAW")
            return

        # ROBOT TURN
        r = robot_move(player, cpu, game)
        print("Robot:", r)

        move_to(current_pos, r)
        current_pos = r
        HEIGHT=6
        reels_down()
        release()
        reels_up()

        game.append(r)
        cpu.append(r)

        if check_win(cpu):
            print("CPU WINS")
            return

        if len(game) == 9:
            print("DRAW")
            return

        # RETURN HOME + PICK
        move_to(current_pos, HOME)
        current_pos = HOME
        reels_down_reset()
        grab()
        reels_up_reset()

# ========================
# --- START ---
# ========================

release()
main()